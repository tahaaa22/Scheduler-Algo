#include <iostream>
using namespace std;
#include "Scheduler.h"
int main()
{
	Scheduler s;
	s. Simulation();
	cout <<endl <<"Simulation endedddd :)" << endl;
	return 0;
}